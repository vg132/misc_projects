31/05/2000	                                            Version 1.1
=======================================================================

Title		: GP1 Lap Edit 1.1
Author		: Viktor Gars
Files		: Gp1 Lap Edit.exe and Readme.txt
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: Change nr of laps
Thanks to	: Geoff Crammond for the best Grand Prix games ever! Gp1, Gp2 and Gp3!

=======================================================================

Construction:
-------------

Base		: No base
Editor(s) used	: Microsoft Visual C++
Known Bugs	: None
Build Time	: 2 days

Features in Version 1.1:
-------------

You can change the nr of laps in a 100% race.
Built in check sum program!
New design!

Installation:
-------------

Unzip and run!

Running GP1 Lap Edit:
-------------

Start the program and then select your Gp1 Track Directory (in the Edit menu). No you will se all the track files in the dir in the list view in the program. You can select if you want to se all files, only .dat files or only f1ct*.dat file. If you want to open a track file from another directory use the Open function in the file menu.
When you click on a file or open a file you will se how many laps there is in a 100% race in  the text box and you can then change this to somthing else between 3 and 127 laps.

Contact:
-------------

Email me if you have any questions, viktor.gars@telia.com or visist my home page at www.vgsoftware.com

Copyright / Permissions:
-------------

You do not have permission to put this tool on any CD-ROM of Gp1 utilities that is to be retailed without the authors prior conscent. You do however have permission to copy GP1 Lap Edit and to distribute it from your webpage.

Disclaimer:
-------------

NOTE!! The author of this package (Program) takes NO responsibility for it's use.

=======================================================================
(C) Viktor Gars 2000