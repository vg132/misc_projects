23/01/2000                                             Version 2.0
=======================================================================

Title		: GP2 Track Editor Frontend v2.0
Author		: Viktor Gars
Files		: tef.exe, gp2form.txt
Email Address 	: formula1@swipnet.se
Homepage	: http://hem1.passagen.se/formula1 - VG Software HomePage
Other Works	: Gp2 Track Handler
		  Gp2 Track Setup Wizard
		  Gp1 Lap Edit
Description	: A Windows frontend for IsoHannula's GP2 Track Editor Plus.

=======================================================================

Construction:
-------------

Base		: No base
Editor(s) used	: Microsoft Visual C++ 6.0
Known Bugs	: None
Build Time	: 5 days

Installation:
-------------

Unzip and start the program. Open the settings menu and select "Set Gp2 Track Edit Path..." and there select your Gp2 Track Editor. The program will work with both Gp2 Track Editor and Gp2 Track Editor Plus.

Contact:
--------

e-mail: formula1@swipnet.se 
HomePage: http://hem1.passagen.se/formula1/

Disclaimer
--------

NOTE!! The author of this package (Program) takes no responsibility for it's use.

=======================================================================
(C) Viktor Gars 1999-2000