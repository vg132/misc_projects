03/09/2000	                                             Version 1.0
=======================================================================

Title		: GPW Misc Edit 1.0
Author		: Viktor Gars
Files		: GPW Misc Edit.exe, readme.txt
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: Editor for Grand Prix World

=======================================================================

Construction:
-------------

Base		: No base
Editor(s) used	: Microsoft Visual C++
Known Bugs	: None
Build Time	: 1 day

Features in Version 1.0
------------------

Start the program and look!

Installation:
-------------

Unzip the files and start the program.
When you have started the program the program will ask you for your Gpw directory, now select your Gpw directory and then select Import form the File menu to import data from Gpw, select Export from the File menu to export data to Gpw.

Contact:
--------

If you have suggestions, comments, or bug reports about GPW Misc Edit, or need support
please e-mail me at viktor.gars@telia.com or visite my homepage http://www.vgsoftware.com/

Copyright / Permissions
--------

You do not have permission to put this tool on any CD-ROM of GPW utilities that is to be retailed without the authors prior conscent. You do however have permission to copy GPWEdit and to distribute it from your webpage.

Disclaimer
--------

NOTE!! The author of this package (Program) takes no responsibility for it's use.

=======================================================================
Copyright (C) Viktor Gars 2000