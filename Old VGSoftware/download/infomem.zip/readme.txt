22/05/2000	                                             Version 1.0
========================================================================

Title		: Info Mem
Author		: Viktor Gars
Files		: Info Mem.exe and readme.txt (this file)
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: This program show info about you system memory use

=======================================================================

Installation:
-------------

Yest run the program!
You must have vb6 runtime files installed on you computer to run this program. You can find them on my web page, www.vgsoftware.com

Copyright / Permissions
--------

This program is Copyright (C) Viktor Gars 2000

Disclaimer
--------

NOTE!! The author of this Program takes no responsibility for it's use.

=======================================================================
(C) Viktor Gars 2000