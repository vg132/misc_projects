03/09/2000	                                             Version 1.0
=======================================================================

Title		: GPW Save File Editor 1.0
Author		: Viktor Gars
Files		: GPWEdit.exe, readme.txt and help files
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: Editor for Grand Prix World Save Files

=======================================================================

Construction:
-------------

Base		: No base
Editor(s) used	: Microsoft Visual C++
Known Bugs	: None
Build Time	: Long time...

Features in Version 1.0
------------------

Start the program and look! :)

Installation:
-------------

Unzip the files and start the program.

Contact:
--------

If you have suggestions, comments, or bug reports about GPW Save File Editor, or need support please e-mail me at viktor.gars@telia.com or visite my homepage http://www.vgsoftware.com/

Copyright / Permissions
--------

You do not have permission to put this tool on any CD-ROM of GPW utilities that is to be retailed without the authors prior conscent. You do however have permission to copy GPWEdit and to distribute it from your webpage.

Disclaimer
--------

NOTE!! The author of this package (Program) takes no responsibility for it's use.

=======================================================================
Copyright (C) Viktor Gars 2000